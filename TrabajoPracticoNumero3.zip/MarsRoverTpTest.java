package MarsRover;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import static org.junit.Assert.assertTrue;
import org.junit.jupiter.api.function.Executable;

class MarsRoverTpTest {

	static int initialCoordinateX = 0, initialCoordinateY = 0;
	static CardinalPoint CardinalPoint = new North();

	@Test
	public void test00CreateNonEmptyRover() {
		assertNotNull(initiateMarsRoverAimingNorth());
	}
	
	@Test
	public void test01CreateRoverOnInitialPositionOnXAxis() {
		assertEquals(initialCoordinates().x, initiateMarsRoverAimingNorth().position.x);
	}
	
	@Test
	public void test02CreateRoverOnInitialPositionOnYAxis() {
		assertEquals(initialCoordinates().y, initiateMarsRoverAimingNorth().position.y);
	}
	
	@Test
	public void test03MoveForward() {
		inspectIfRoverMovesAsExpected(initiateMarsRoverAimingNorth(),"f", 0, 1);
	}

	@Test
	public void test04MoveBackwardsTest() {
		inspectIfRoverMovesAsExpected(initiateMarsRoverAimingNorth(),"b", 0, -1);
	}

	@Test
	public void test05MoveLeftTest() {
		assertTrue(initiateMarsRoverAimingNorth().associateStringWithCommandToExecute("l").direction instanceof West);
	}

	@Test
	public void test06MoveRightTest() {
		assertTrue(initiateMarsRoverAimingNorth().associateStringWithCommandToExecute("r").direction instanceof East);
	}

	@Test
	public void test07InvalidCommandGiven() {
		assertThrowsLike(() -> initiateMarsRoverAimingNorth().associateStringWithCommandToExecute("fba"), Command.invalidCommandMessage);	
	}

	@Test
	public void test08RotateOnly() {
		inspectIfRoverMovesAsExpected(initiateMarsRoverAimingNorth(),"rlllrrr", 0, 0);
	}

	@Test
	public void test09MovementOnly() {
		String onlyMovement = "ffbbffbbfffb";
		assertTrue(initiateMarsRoverAimingNorth().associateStringWithCommandToExecute(onlyMovement).direction instanceof North);
	}
	
	@Test
	public void test10MultimpleCommandsToExecute() {
		inspectIfRoverMovesAsExpected(initiateMarsRoverAimingNorth(),"ffbf", 0, 2);
	}
	
	@Test
	public void test11MoveForwardToNorth() {
		inspectIfRoverMovesAsExpected(initiateMarsRoverAimingNorth(),"f", 0, 1);
	}
	
	@Test
	public void test12MoveForwardToSouth() {
		inspectIfRoverMovesAsExpected(initiateMarsRoverAimingSouth(), "f", 0, -1);
	}
	
	@Test
	public void test13MoveForwardToWest() {
		inspectIfRoverMovesAsExpected(initiateMarsRoverAimingWest(), "f", -1, 0);
	}

	@Test
	public void test14MoveForwardToEast() {
		inspectIfRoverMovesAsExpected(initiateMarsRoverAimingEast(), "f", 1, 0);
	}
	
	@Test
	public void test15MoveBackwardsToTheNorth() {
		inspectIfRoverMovesAsExpected(initiateMarsRoverAimingNorth(), "b", 0, -1);
	}

	@Test
	public void test16MoveBackwardsToTheSouth() {
		inspectIfRoverMovesAsExpected(initiateMarsRoverAimingSouth(), "b", 0, -1);
	}

	@Test
	public void test17MoveBackwardsToWest() {
		inspectIfRoverMovesAsExpected(initiateMarsRoverAimingWest(), "b", 1, 0);
	}

	@Test
	public void test18MoveBackwardsToTheEast() {
		inspectIfRoverMovesAsExpected(initiateMarsRoverAimingEast(), "b", -1, 0);
	}	
	
	@Test
	public void test19RotateLeftToTheNorth() {
		inspectIfRoverMovesAsExpected(initiateMarsRoverAimingNorth(), "l", 0, 0);
	}

	@Test
	public void test20RotateLeftToTheSouth() {
		inspectIfRoverMovesAsExpected(initiateMarsRoverAimingSouth(), "l", 0, 0);
	}

	@Test
	public void test21RotateLeftToWest() {
		inspectIfRoverMovesAsExpected(initiateMarsRoverAimingWest(), "l", 0, 0);
	}

	@Test
	public void test22RotateLeftToTheEast() {
		inspectIfRoverMovesAsExpected(initiateMarsRoverAimingEast(), "l", 0, 0);
	}


	@Test
	public void test23RotateRightToTheNorth() {
		inspectIfRoverMovesAsExpected(initiateMarsRoverAimingNorth(), "r", 0, 0);
	}

	@Test
	public void test24RotateRightToTheSouth() {
		inspectIfRoverMovesAsExpected(initiateMarsRoverAimingSouth(), "r", 0, 0);
	}
	
	@Test
	public void test25RotateRightToTheWest() {
		inspectIfRoverMovesAsExpected(initiateMarsRoverAimingWest(), "r", 0, 0);
	}

	@Test
	public void test26RotateRightToTheEast() {
		inspectIfRoverMovesAsExpected(initiateMarsRoverAimingEast(), "r", 0, 0);
	}
	
	@Test
	public void test27UndoMovement() {
		inspectIfRoverMovesAsExpected(initiateMarsRoverAimingEast(), "bf", 0, 0);
	}
	
	private CoordinatePoint initialCoordinates() {
		return new CoordinatePoint(initialCoordinateX, initialCoordinateY);
	}
	
	private MarsRover initiateMarsRoverAimingNorth() {
		return new MarsRover( initialCoordinates(), CardinalPoint);
	}
	
	private MarsRover initiateMarsRoverAimingSouth(){
		return new MarsRover( initialCoordinates(), new South());
	}
	
	private MarsRover initiateMarsRoverAimingWest(){
		return new MarsRover( initialCoordinates(), new West());
	}
	
	private MarsRover initiateMarsRoverAimingEast(){
		return new MarsRover( initialCoordinates(), new East());
	}

	private void assertThrowsLike(Executable executable, String message) {
		assertEquals(message, assertThrows(Exception.class, executable).getMessage());
	}
	
	private boolean inspectNewCoordinates(MarsRover rover, int x, int y) {
		return rover.checkCoordinates(new CoordinatePoint(x, y));
	}
	
	private void inspectIfRoverMovesAsExpected(MarsRover rover, String commands, int x, int y) {
		rover.associateStringWithCommandToExecute(commands);
		assertTrue(inspectNewCoordinates(rover, x, y));
	}
}

