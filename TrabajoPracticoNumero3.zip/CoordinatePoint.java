package MarsRover;

public class CoordinatePoint {
	int x;
	int y;
	
	public CoordinatePoint(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public CoordinatePoint updatePosition(CoordinatePoint MovementVector) {
		x+=MovementVector.x;
		y+=MovementVector.y;
		return this; 
	}

	
}

