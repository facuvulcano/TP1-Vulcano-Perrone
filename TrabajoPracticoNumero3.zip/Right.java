package MarsRover;

public class Right extends Command {

	public Right() {
		super('r');
	}
	
	@Override
	public boolean canHandle(char command) {		
		return commandIdentifierValue == command;
	}

	@Override
	public void execute(MarsRover rover) {
		rover.direction = rover.direction.rightCardinalPoint();
		
	}
	
}
