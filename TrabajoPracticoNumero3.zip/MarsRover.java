package MarsRover;

import java.util.ArrayList;
import java.util.List;

public class MarsRover {
	 
	public List<Command> commands = new ArrayList<>(List.of(new Forward(), new Backward(), new Left(), new Right()));
	
	public CoordinatePoint position;
	public CardinalPoint direction;
	public Command command;
	
	public MarsRover (CoordinatePoint position, CardinalPoint direction) {
		this.position = position;
		this.direction = direction;
	}
	
	public void executeCommand(Character command) {
	    Command commandToExecute = commands.stream()
	        .filter(commandIdentifier -> commandIdentifier.canHandle(command))
	        .findFirst()
	        .orElse(new ErrorCommand());
		commandToExecute.execute(this);
	}
	
	public MarsRover associateStringWithCommandToExecute(String command) {
			for (Character validCharacter : command.toCharArray())
				this.executeCommand(validCharacter);
			return this;
		}

	public boolean checkCoordinates(CoordinatePoint coordinates) {
		if (this.position.x == coordinates.x && this.position.y == coordinates.y) {
			return true;
		}
		return false;
	}

}
