package MarsRover;

public abstract class Command {
	
	public static String invalidCommandMessage = "Invalidad command received";
	
	public char commandIdentifierValue;
	
	public Command(char command) {
		this.commandIdentifierValue = command;
	}	
	
	public abstract boolean canHandle(char command);
	
	public abstract void execute(MarsRover rover);
	
	}

